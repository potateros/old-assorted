Every one of these programs are made by me with help from computergeek.com
All rights reserved.
Please do not copy me or any of my hard work.
Dedicated to my friend, Adam.
Enjoy!

Programs contained inside:
-An amazing colour changing window
-A virus detecter
-A Simple Calculator
-A Password Finder
-A bogus disk eraser
-Matrix v1
-Matrix v1.5
-Matrix v2
-Blue Screen of Death
-Bogus GTA IV extracter


Note: Excessive Usage may lead to extreme indigestion

When double-clicked, choose 'Run' instead of 'Extract All'
